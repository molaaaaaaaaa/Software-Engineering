package exam.base.constants;

/**
 * 考试信息常量 
 *
 */
public class ExamConstants {
	
	//当前未结束的考试状态
	public static final String STATE_CUR_VALID_EXAM = "1";
	
	//北京地区的ID
	public static final String REGION_BEIJING = "1";
}
