 $(function(){
	$("#online_exam-dtl-from-submitBtn").click(online_exam_onExamInfoConfirmOk);

});
function online_exam_onExamInfoConfirmOk(){
		comm_ui_showMessage("作答成功");
}


